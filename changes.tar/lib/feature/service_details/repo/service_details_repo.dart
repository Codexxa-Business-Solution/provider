import 'package:get/get.dart';
import 'package:demandium_provider/core/helper/core_export.dart';

class ServiceDetailsRepo{
  final ApiClient apiClient;
  final SharedPreferences sharedPreferences;
  ServiceDetailsRepo({required this.apiClient,required this.sharedPreferences});

  Future<Response> getServiceDetailsData(String serviceId) async {
    return await apiClient.getData('${AppConstants.SERVICE_DETAILS_URL}/${serviceId}');
  }

  Future<Response> getServiceFAQData(String serviceId) async {
    return await apiClient.getData(AppConstants.SERVICE_FAQ_URL+"?limit=30&offset=1&service_id="+serviceId);
  }

}